# Readability
# Description
# Do not execute

# readability
a = 12

b = 12  # a comment

# c = 13

# thee double qoutes
"""
multiline comments
Hello 
this is a comment
"""

'''
This is a comment too.
'''


# python doc
def a_method(a):
    """
    This is a test method

    :param a: this is an integer
    :type a: integer
    :return:
    :rtype:
    """
    print(f"Hello {a}")


a_method(10)

# todo: refactor this part
# todo: rewrite this part
# Todo: rewrite this part
# TODO: rewrite this part
