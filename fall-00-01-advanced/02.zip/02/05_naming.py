# underline and alphabet(uppercase and lowercase)
_a = 12
a_b = 12
# *a = 12

# فارسی = 12
# print(فارسی)

# can not start with numbers
# 2and1 = 2 SyntaxError: invalid syntax

# no reserved keywords
# https://www.tutorialspoint.com/What-are-Reserved-Keywords-in-Python#:~:text=What%20are%20Reserved%20Keywords%20in%20Python%3F%20Reserved%20words,programming%20elements%20like%20name%20of%20variable%2C%20function%20etc.
# and = 2
# or = 2
# if

# you can not use dash and space
# a-b = 12
# a b = 12
# a@b =12
# a* = 12
# a% = 12
