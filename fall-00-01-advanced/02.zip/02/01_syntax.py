# indentation

# no semi-colom

# do not do this
if True:
  print("Hello world")
  print("Hello world")
else:
      print("Hello world")
      print("Hello world")

# syntax error
# if True:
#     print("Hello world")
#   print("Hello world")
# else:
#     print("Hello world")

