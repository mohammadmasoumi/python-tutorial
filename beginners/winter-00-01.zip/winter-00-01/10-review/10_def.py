
"""
f(x) = x ^ 2
f(2) = 4
f(3) = 9

f(x, y) = x ^ 2 + y ^ 2
f(1, 2) = 1 + 4 = 5

g(x) = x ^ 3


def function_name(function_inputs):
    return function_output

def function_name(param1, param2, param3):
    return return1, return2 


value = function_name(params)
value = function_output

function_name(params)
"""