

"""
1. condition
2. code block
3. condition
4. code block

while condition < 10:
    # code block
    condition += 1


while True:
    if condition:
        break

"""
counter = 0

while counter < 10:
    print("Hello ")

    if counter == 5:
        counter += 2
    else:
        counter += 1

# infinitive loop
# while True:
#     if False:
#         break
    
#     print("Hello")