# variable 

# variable
# value

# variable 
#   name: a
#   value: 12
#   type: int
a = 12

# immutable
# mutable

# why we need variable?
# Mobin => Asghar
name = "Asghar"

print(f"Hello {name}!")
print(f"How are you {name}?")
print(f"Where are you from {name}?")
print(f"Goodbye {name}")

# save
