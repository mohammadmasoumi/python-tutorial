# assignment = 
# int, str, bool, float

# [TYPE]: str
b = 'Hello world ----------------'

# print: build-in function 
print(b)

# [TYPE]: int
c = 12
print(c) # NameError: name 'c' is not defined
print("Hello world ...............")

# c = 12

# [TYPE]: float
grade = 18.45
grade1: int = 18.45
print(grade1)

# [TYPE]: bool | True False
is_male = True
is_female = False
