# time convertor

# 1. hour = input
# 2. convert hour -> minute
# 3. print 


hour = int(input())
# convert to minutes
# str * int 
# "3" * 60 => "333333333333333333333333333333333333333333333333333333333333"
converted = hour * 60
print(converted)

# in one line
# print(int(input()) * 60)

