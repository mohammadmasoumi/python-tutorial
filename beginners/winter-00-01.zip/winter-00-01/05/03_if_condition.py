
"""
if condition:
    statment
    statment
    statment
    statment
    statment
"""


# comparison operator
# ==. >, <, ...
# logical operator
# and or 
# condition1 and condition1
a = 12
if a == 12:
    print("Bingo")

a = 13
if a == 13:
    print("Bye")

if a == 14:
    print("Good morning!")
else:
    print("Good afternoon!")
