names = ["hassan","asghar", "mina", "maryam"]
grades = [10, 20, 19.9, 15.2]
ages = [10, 20 ,10 , 20]

print(zip(names, grades))
print(list(zip(names, grades)))
print(dict(zip(names, grades)))
# [('hassan', 10), ('asghar', 20), ('mina', 19.9), ('maryam', 15.2)]
print(list(zip(names, grades, ages)))
print("--------------------------")

names = ["hassan","asghar", "mina"]
grades = [10, 20, 19.9, 15.2]
m



print(list(zip(names, grades)))
print("--------------------------")

names = ["hassan","asghar", "mina", "soghra", "marry"]
grades = [10, 20, 19.9, 15.2]

print(list(zip(names, grades)))

