# object

# function
# variable

def hello():
    print("Hello, How are you?")


greeting1 = hello
print(greeting1)
hello()
greeting1()

greeting2 = hello()
print(greeting2)