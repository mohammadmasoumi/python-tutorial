"""
1. params - return None
2. key/value, positional args
3. default value
4. force key-value/positional
5. infinitive args
6. multiple return
"""

"""
def function_name(params):
    # function block
    # code block
    return []


a = function_name()
print(function_name())
function_name()
"""

# return None

# no return statement
def return_none_1():
    a = 12

def return_none_2():
    return 

def return_none_3():
    return None


print(return_none_1())
print(return_none_2())
print(return_none_3())