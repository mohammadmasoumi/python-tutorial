# 
my_list = ["ali", "hassan", "maryam"]
print(my_list.index("ali")) # get the index of value
print(my_list[0])
print(my_list.index(my_list[0])) # get the index of value


my_list = [1, 2 ,3 ,4]
print(my_list.index(4)) # get the index of value

