my_list = [1, 2, 3, 4]

acc = 1
for elem in my_list:
    acc *= elem

print(f"acc: {acc}")