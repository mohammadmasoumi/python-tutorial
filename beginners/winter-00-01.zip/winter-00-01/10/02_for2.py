
my_list = ["a", "b", "c", "d"]

acc = ""

for elem in my_list:
    acc += elem

print(f"acc: {acc}")