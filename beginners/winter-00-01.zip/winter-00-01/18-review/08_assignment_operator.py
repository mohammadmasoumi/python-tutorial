my_tuple = (1, 2, 3, 4)
my_int = 12

# my_tuple = my_tuple + (5, 6) 
my_tuple += (5, 6)
my_tuple2 = my_tuple + (5, 6)
my_tuple = my_tuple + (5, 6)

# my_int = my_int + 1
my_int += 1

print(my_tuple)
print(my_int)
