
"""
- list
- tuple
- set


Set
محموعه

    1. Duplication now allowed
    2. Unordered - no index
    3. Changeable

"""

# int, str, list, tuple, float
my_set1 = set() # {}, you must use set keyword
my_set2 = {2, 3, 2}


# NameError: name 'my_set1' is not defined
# del my_set1
# my_set1.clear()

my_set1.copy()

print(my_set1) # {1}
print(my_set2)