my_set1 = set()

# remove
# raise exception if element does not exist
my_set1.remove(1)

# KeyError: 10
# my_set1.remove(10)