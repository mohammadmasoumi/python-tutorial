my_set1 = set()

# add 
my_set1.add(1)
my_set1.add(1)


# TypeError: add() takes exactly one argument (2 given)
# my_set1.add(1, 2)