my_set1 = set()

# discard
my_set1.discard(10)
