set1 = {1, 2, 4}
set2 = {1, 2, 3}


print(set1 ^ set2) # symmetric diff
print(set1 | set2) # union
print(set1 & set2) # intersection