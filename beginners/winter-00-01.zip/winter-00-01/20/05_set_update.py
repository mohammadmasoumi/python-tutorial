my_set1 = set()

# update
my_set1.update([2, 3])
my_set1.update("Hello")
my_set1.add("Hello")
my_set1.update((100, 200))
