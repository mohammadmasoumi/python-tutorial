
d = {}

key = "my_key"

d[key] = "new value"
d['my_key'] = "new value"

d.update(key="new value")

print(d)