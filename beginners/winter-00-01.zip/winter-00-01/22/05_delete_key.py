d = {
    "key1": "value1",
    "key2": "value2",
}

# list
# last item
# item = d.pop()

# index 0 
# item = d.pop(0)

my_key = 'key1'
value = d.pop(my_key)

print(d)
print(f"{my_key}: {value}")