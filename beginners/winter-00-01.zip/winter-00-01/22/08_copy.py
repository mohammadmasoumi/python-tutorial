d1 = {
    "key1": "value1",
    "key2": "value2"
}

d2 = {**d1}