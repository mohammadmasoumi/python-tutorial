# dict


# dataset
# list
# set
# tuple
# int 
# str
# float
# bool

# dict
# key - value

my_set1 = set()
my_set2 = {1, 2}

print(f"my_set1: {my_set1}, type: {type(my_set1)}")
print(f"my_set2: {my_set2}, type: {type(my_set2)}")

my_dict1 = {}
my_dict2 = {
    'key1': 'value1',
    'name': 'asghar',
    'age': 12,
    12: 12,
    12.2: 2,
    True: 'asghar',
    (1, 2): 'akbar',
    1: 'mobin',
    12: 13
}
# {'key1': 'value1', 'name': 'asghar', 'age': 12, 12: 13, 12.2: 2, True: 'mobin', (1, 2): 'akbar'}
print(my_dict2)





