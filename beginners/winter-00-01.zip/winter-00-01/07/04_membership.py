fruits = ["orange", "watermelon", "coconut"]

# membership
print(int("coconut" in fruits))
print("coconut" not in fruits)