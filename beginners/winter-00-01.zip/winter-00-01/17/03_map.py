my_list = ["1", "2", "3", "4"]

# def cast_to_int(item):
#     return int(item)


print(my_list)
print(list(map(int, my_list)))
# print(list(map(cast_to_int, my_list)))