print(list(filter(lambda x: not x % 2, map(int, input().split()) )))
print(list(filter(   lambda x: True if x % 2 == 0 else False ,    map(int, input().split())      )))




