my_list = [1, 2, 3, 4]
def my_func(item):
    item *= 2


print(list(map(my_func, my_list)))