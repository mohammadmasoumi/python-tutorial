# f(x) = x^2
# f(2) = 4
# my_func(2) = 4

def my_func(item):
    return item * 2

print(list(map(int, input().split())))