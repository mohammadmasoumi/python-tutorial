h = 12

if h > 23:
    value  = "Bye"
else:
    value = "Hello"

# inline if-else
# زمانی که مقدار یک متغیر با یک شرط تعیین میشود.
value = "Bye" if  h > 23 else "Hello"