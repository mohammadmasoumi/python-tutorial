my_tuple = (1, 2, [3, 4])

my_tuple[2].append(10)

print(my_tuple)