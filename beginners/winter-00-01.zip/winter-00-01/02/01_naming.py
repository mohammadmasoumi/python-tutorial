# ctrl + F - search in file
# https://www.c-sharpcorner.com/article/visual-studio-code-keyboard-shortcut-for-windows/

# datatypes
# int 
# bool
# float
# str

# variables
# name
# type
# value

age = 12
grade = 12.5
name = "ali" # string of characters
is_male = True # False

# name = input()

# print(age)
# print("age")
# print("age:", age)

# type ??
# khuruji = print(vorudi)
# khuruji = type(vorudi)
# type method/function takes only 1 argument

# fog
# f(   g(x) )
# y = g(x)
# z= f(y)

type_of_age = type(age)

# print the value of type_of_age variable
print( type_of_age )
print( type(age) )

# reusable - you can use type_of_age variable latter in the program
print( type_of_age )

print("---------------------------------")
print(type(age), age) # \n newline
print(type(grade), grade)
print(type(name), name)
print(type(is_male), is_male)

# <class 'int'> 12<class 'float'> 12.5<class 'str'> ali<class 'bool'> True

# <class 'int'> 12\n
# <class 'float'> 12.5\n
# <class 'str'> ali\n
# <class 'bool'> True

print("---------------------------------")
print(type(age), age, type(grade), grade, type(name), name, type(is_male), is_male)