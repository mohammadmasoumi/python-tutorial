# assignment operator

# =
a = 12

# a = a + 2
a += 2
print(a)
a -= 2
print(a)
a *= 2
print(a)
a //= 2
print(a)
a /= 2
# a = int(a)
print(a)
a **= 2
print(a)