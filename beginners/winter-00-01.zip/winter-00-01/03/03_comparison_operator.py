# comparison operator

a = 12
b = 13
c = 13
d = 14

print(a > b) # True ? False = False
print(a >= b) # False
print(b >= c) # True 
print(b >= d) # False
print(b == c)
print(b != c) 
print(b < c)
print(b <= c)

