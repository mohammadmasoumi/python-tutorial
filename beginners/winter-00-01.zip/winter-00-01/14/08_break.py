

for item in ["a", "b", "c"]:

    if item == "a":
        break 
        # unreachable code
        # this line does not execute
        print(item)

    