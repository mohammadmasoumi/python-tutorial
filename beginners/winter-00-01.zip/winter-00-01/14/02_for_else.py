my_list = ["mobin", "mahdi", "ali"]

"""
for
else
"""

for name in my_list:
    if name == "ali":
        print("I find Ali")
        break
else:
    # if break does not execute  
    print("I didn't find Ali")
