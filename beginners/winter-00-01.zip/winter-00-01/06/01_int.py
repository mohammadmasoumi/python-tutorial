# int
# float
# complex number

a = 12 # int
b = 12.0000000000000000000000002 # float
c = 12j # real + imaginary
# real: 12, imagenary: 1
d = 12 + 1j
