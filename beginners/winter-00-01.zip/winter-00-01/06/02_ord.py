# ord - chr

# ascii code
# A?
# a

# character -> ascii code
print(ord("a"))
print(ord("b"))
print(ord("z"))
print(ord("A"))
print(ord("Z"))
print(ord("!"))
print(ord("☺"))
print("--------------------")
# ascii code -> character
print(chr(1))
print(chr(0))
# print(chr(-10))
print(  ord(chr(1))  )
print(chr(9786))