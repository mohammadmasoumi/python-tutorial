# "FILE_NAME.py"

# install extensions
# 1. Python
# 2. Atom one Dark theme

# Comment usages:
# 1. Descriptions
# 2. Reminder
# 3. Debugging

# short cut
# comment: ctrl + /
# multiple select: shift + arrow keys

# double quate / single quate
# todo: Remove this line

# Interepreter
# Compiler

# Variables
# 1. type
# 2. name
# 3. value

# str a = "Hello world"

a = "Hello world"  # this is a variable which do sth

a = 12
# this is a variable which do sth
b = 'Hello world'
