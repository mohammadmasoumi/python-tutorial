# 1. Must no start with number
# 01_name = "Ali"

# 2. must contains alphabetic and numeric characters + _
name01 = "Ali"
first_name = "Ali" # _ is allowed
first0name = "ali"
# first-name = "ali"
# first#name = "ali"
# first$name = "ali"

# 3. reserved keyword
# if = 12
# for = 12
# + = 12

# 4. naming convernsion
FIRSTNAME = "ali" # constant
firstname = "ali" # Ok
FirstName = "ali" # just for classes
firstName = "ali" # Wrong
Firstname = "ali" # Wrong
first_name = "ali" # python preference

# snake_case Python
# name_name_name_name

# pascalcase
# FirstNameFirstNameFirstName

# camelcase
# firstNameFirstNameFirstNameFirstName