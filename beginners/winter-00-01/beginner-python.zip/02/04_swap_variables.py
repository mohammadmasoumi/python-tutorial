
# a = 12
# b = 13

# a, b = 12, 13

# print("a:", a, "b", b)

# a, b = b, a

# print("a:", a, "b", b)


# second solution 

# a = 12
# b = 13

# b = a + b 
# a = b - a
# b = b - a

# print(a, b)

# third solution
a = 12
b = 13
temp = 0

temp = a
a = b
b = temp

print(a, b)