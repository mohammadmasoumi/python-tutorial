# float = int / int
print(10 / 2)

# float = int / float
print(10 / 2.0)

# float = float / float
print(10.0 / 2.0)

# int = int // int
print(10 // 2)

# float = int // float
print(10 // 2.0)

# float = float // float
print(10.0 // 2.0)

# -------------------
# TypeError: unsupported operand type(s) for /: 'float' and 'str'
# print(10.2 / "ab")
